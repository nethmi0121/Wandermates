package com.example.wandermates

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ForgotPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_pw)

        val backToLogin = findViewById<TextView>(R.id.back_to_login)

        // Set an OnClickListener for the 'Back to Login' TextView
        backToLogin.setOnClickListener {
            // Navigate back to the LoginActivity
            val intent = Intent(this@ForgotPasswordActivity, LogInActivity::class.java)
            startActivity(intent)
            finish() // Finish current activity to prevent going back to it
        }
    }
}
