package com.example.wandermates

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment

class BookingsFragment : Fragment() {

    private lateinit var bookingTitle: TextView
    private lateinit var vehicleTypeLabel: TextView
    private lateinit var vehicleTypeSpinner: Spinner
    private lateinit var destinationLabel: TextView
    private lateinit var destinationSpinner: Spinner
    private lateinit var dateLabel: TextView
    private lateinit var datePicker: EditText
    private lateinit var submitBooking: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_bookings, container, false)

        val bookingTitle = view.findViewById<TextView>(R.id.booking_title)
        val vehicleTypeLabel = view.findViewById<TextView>(R.id.vehicle_type_label)
        val vehicleTypeGroup = view.findViewById<RadioGroup>(R.id.vehicle_type_group) // Updated to RadioGroup
        val destinationLabel = view.findViewById<TextView>(R.id.destination_label)
        val destinationText = view.findViewById<EditText>(R.id.destination_text) // Updated to EditText
        val dateLabel = view.findViewById<TextView>(R.id.date_label)
        val datePicker = view.findViewById<EditText>(R.id.date_picker) // Updated to EditText
        val submitBooking = view.findViewById<Button>(R.id.submit_booking)



        return view
    }
}
