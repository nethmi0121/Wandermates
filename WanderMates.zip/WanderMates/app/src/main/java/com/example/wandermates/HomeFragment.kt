package com.example.wandermates

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Set image and text dynamically
        val imageElla: ImageView = view.findViewById(R.id.image_ella)
        val destinationElla: TextView = view.findViewById(R.id.destination_ella)

        imageElla.setImageResource(R.drawable.ella) // Replace with actual drawable
        destinationElla.text = "Ella - A breathtaking waterfall destination"

        return view
    }
}
