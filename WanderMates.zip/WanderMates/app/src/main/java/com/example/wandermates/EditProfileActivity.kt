package com.example.wandermates

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class EditProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val fullNameEditText = findViewById<EditText>(R.id.edit_full_name)
        val usernameEditText = findViewById<EditText>(R.id.edit_username)
        val emailEditText = findViewById<EditText>(R.id.edit_email)
        val saveButton = findViewById<Button>(R.id.btn_save)

        saveButton.setOnClickListener {
            Toast.makeText(this, "Changes Saved!", Toast.LENGTH_SHORT).show()
        }
    }
}
