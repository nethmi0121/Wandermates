package com.example.wandermates

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class SearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        val listView: ListView = findViewById(R.id.listView_search)

        val destinations = listOf(
            "Anuradhapura - Ancient city with temples",
            "Unawatuna - Beautiful beach and coral reefs",
            "Ella - Scenic train rides and hiking",
            "Sigiriya - Ancient rock fortress",
            "Mirissa - Whale watching and beaches"
        )

        // Setting up a simple list adapter
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, destinations)
        listView.adapter = adapter
    }
}
